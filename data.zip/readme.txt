first column - voltage
second column - angle

rest - current and current angle

last column - frequency